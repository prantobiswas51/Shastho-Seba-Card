<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.card-resource.pages.create-card' => 'App\\Filament\\Resources\\CardResource\\Pages\\CreateCard',
    'app.filament.resources.card-resource.pages.edit-card' => 'App\\Filament\\Resources\\CardResource\\Pages\\EditCard',
    'app.filament.resources.card-resource.pages.list-cards' => 'App\\Filament\\Resources\\CardResource\\Pages\\ListCards',
    'app.filament.resources.card-resource.pages.view-card' => 'App\\Filament\\Resources\\CardResource\\Pages\\ViewCard',
    'app.filament.resources.card-transaction-resource.pages.create-card-transaction' => 'App\\Filament\\Resources\\CardTransactionResource\\Pages\\CreateCardTransaction',
    'app.filament.resources.card-transaction-resource.pages.edit-card-transaction' => 'App\\Filament\\Resources\\CardTransactionResource\\Pages\\EditCardTransaction',
    'app.filament.resources.card-transaction-resource.pages.list-card-transactions' => 'App\\Filament\\Resources\\CardTransactionResource\\Pages\\ListCardTransactions',
    'app.filament.resources.member-resource.pages.create-member' => 'App\\Filament\\Resources\\MemberResource\\Pages\\CreateMember',
    'app.filament.resources.member-resource.pages.edit-member' => 'App\\Filament\\Resources\\MemberResource\\Pages\\EditMember',
    'app.filament.resources.member-resource.pages.list-members' => 'App\\Filament\\Resources\\MemberResource\\Pages\\ListMembers',
    'app.filament.resources.organization-resource.pages.create-organization' => 'App\\Filament\\Resources\\OrganizationResource\\Pages\\CreateOrganization',
    'app.filament.resources.organization-resource.pages.edit-organization' => 'App\\Filament\\Resources\\OrganizationResource\\Pages\\EditOrganization',
    'app.filament.resources.organization-resource.pages.list-organizations' => 'App\\Filament\\Resources\\OrganizationResource\\Pages\\ListOrganizations',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\Users\\prant\\OneDrive\\Desktop\\Shastho-Seba-Card\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    0 => 'App\\Filament\\Resources\\CardTransactionResource',
    'C:\\Users\\prant\\OneDrive\\Desktop\\Shastho-Seba-Card\\app\\Filament\\Resources\\CardResource.php' => 'App\\Filament\\Resources\\CardResource',
    'C:\\Users\\prant\\OneDrive\\Desktop\\Shastho-Seba-Card\\app\\Filament\\Resources\\CardTransactionResource.php' => 'App\\Filament\\Resources\\CardTransactionResource',
    'C:\\Users\\prant\\OneDrive\\Desktop\\Shastho-Seba-Card\\app\\Filament\\Resources\\MemberResource.php' => 'App\\Filament\\Resources\\MemberResource',
    'C:\\Users\\prant\\OneDrive\\Desktop\\Shastho-Seba-Card\\app\\Filament\\Resources\\OrganizationResource.php' => 'App\\Filament\\Resources\\OrganizationResource',
    'C:\\Users\\prant\\OneDrive\\Desktop\\Shastho-Seba-Card\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\Users\\prant\\OneDrive\\Desktop\\Shastho-Seba-Card\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\Users\\prant\\OneDrive\\Desktop\\Shastho-Seba-Card\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);