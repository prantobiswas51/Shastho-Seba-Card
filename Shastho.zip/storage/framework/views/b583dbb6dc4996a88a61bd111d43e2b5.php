<div
    class="fi-ta-placeholder text-sm leading-6 text-gray-400 dark:text-gray-500"
>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\prant\OneDrive\Desktop\Shastho-Seba-Card\vendor\filament\tables\resources\views\components\columns\placeholder.blade.php ENDPATH**/ ?>